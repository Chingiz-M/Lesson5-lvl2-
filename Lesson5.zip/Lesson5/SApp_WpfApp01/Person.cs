﻿using SApp_WpfApp01.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SApp_WpfApp01
{
    public class Person
    {
        public string Name { get; set; }
        public DateTime Birthday { get; set; }
        public Gender Gender { get; set; }
        public Department Department { get; set; }

        public Person(string name, DateTime birthday, Gender gender, Department department)
        {
            Name = name;
            Birthday = birthday;
            Gender = gender;
            Department = department;
        }
    }
}
