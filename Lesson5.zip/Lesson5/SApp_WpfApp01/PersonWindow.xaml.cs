﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SApp_WpfApp01
{
    /// <summary>
    /// Interaction logic for PersonalWindow.xaml
    /// </summary>
    public partial class PersonWindow : Window
    {
        public List<Person> personList = new List<Person>();
        static public List<Department> departmentList = new List<Department>();
        
        public PersonWindow()
        {
            InitializeComponent();

            departmentList.AddRange(new[] {
                new Department("Первый"),
                new Department("Второй"),
                new Department("Технический")
                });

            personList.AddRange(new[] { 
                new Person("Андрей", new DateTime(1998, 10, 9), Controls.Gender.Male, departmentList[0]),
                new Person("Светлана", new DateTime(2001, 12, 19), Controls.Gender.Female, departmentList[1]),
                new Person("Павел", new DateTime(2005, 7, 20), Controls.Gender.Male, departmentList[2]),
                new Person("Сергей", new DateTime(2001, 2, 1), Controls.Gender.Male, departmentList[2]),
                new Person("Мария", new DateTime(2001, 1, 2), Controls.Gender.Female, departmentList[0]),
                new Person("Владимир", new DateTime(2001, 1, 6), Controls.Gender.Male, departmentList[1]),
            });

            personListView.ItemsSource = personList;
            ColB.Width = personList[0].Birthday.ToString().Length * 10;

            departmentComboBox.ItemsSource = departmentList;
        }

        private void personListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count != 0)
            {
                nameTextBox.Text = (e.AddedItems[0] as Person).Name;
                birthdayDatePicker.SelectedDate = (e.AddedItems[0] as Person).Birthday;
                genderControl.Gender = (e.AddedItems[0] as Person).Gender;
                departmentComboBox.SelectedItem = (e.AddedItems[0] as Person).Department;
            }
        }

        private void saveButton_Click(object sender, RoutedEventArgs e)
        {
            if (personListView.SelectedItem != null)
            {
                var person = (Person)personListView.SelectedItem;

                person.Name = nameTextBox.Text;
                person.Birthday = (DateTime)birthdayDatePicker.SelectedDate;
                person.Gender = genderControl.Gender;
                person.Department = (Department)departmentComboBox.SelectedItem;

                personListView.ItemsSource = null;
                personListView.ItemsSource = personList;
            }
        }

        private void addButton_Click(object sender, RoutedEventArgs e)
        {
            AddPersonWindow wnd = new AddPersonWindow();
            if(wnd.ShowDialog() == true)
            {
                personList.Add(wnd.Person);
                personListView.ItemsSource = null;
                personListView.ItemsSource = personList;
            }
        }

        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (personListView.SelectedItem != null)
            {
                personList.Remove((Person)personListView.SelectedItem);
                personListView.ItemsSource = null;
                personListView.ItemsSource = personList;
            }
        }
    }
}
